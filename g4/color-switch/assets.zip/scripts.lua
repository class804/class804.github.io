function class(base, init)
   local c = {}    -- a new class instance
   if not init and type(base) == 'function' then
      init = base
      base = nil
   elseif type(base) == 'table' then
      for i,v in pairs(base) do
         c[i] = v
      end
      c._base = base
   end
   c.__index = c
   local mt = {}
   mt.__call = function(class_tbl, ...)
   local obj = {}
   setmetatable(obj,c)
   if init then
      init(obj,...)
   else 
      if base and base.init then
      base.init(obj, ...)
      end
   end
   return obj
   end
   c.init = init
   c.is_a = function(self, klass)
      local m = getmetatable(self)
      while m do 
         if m == klass then return true end
         m = m._base
      end
      return false
   end
   setmetatable(c, mt)
   return c
end

obj_root_avoider = class()
function obj_root_avoider:timer(dt)
    function game_start()
        print ("state game_start called")
        self.start_t=os.time()
    end
    function game_end()
        self.end_t=os.time()
    end
    if 	(state == "start_level") then
        game_start()
    end
    if 	(state == "apply") then
        game_end()
    end
end

obj_root_cake = class()
function obj_root_cake:state(state,guestID)
 function game_start()
    		print ("state game_start called")
        self.start_t=os.time()
  	end
    function game_end()
        self.end_t=os.time()
    end
 	if 	(state == "start_level") then
		game_start()
	end
  if 	(state == "apply") then
		game_end()
	end
end

